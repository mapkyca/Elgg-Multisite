<?php

	/**
	 * Show members online
	 **/
	 
	 echo "<div class=\"members_online\">";
	 echo get_online_users();
	 echo "</div>";
	 
?>