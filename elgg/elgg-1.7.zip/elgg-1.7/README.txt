Elgg version 1.7
Copyright (c) 2008-2010 Curverider Ltd

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  
USA


ABOUT:

See CONTRIBUTORS.txt for development credits.

Elgg concept originally by:
Ben Werdmuller <ben@elgg.com> and David Tosh <dave@elgg.com>

The open source project site can be found at http://elgg.org/

Elgg is released under the GNU Public License (GPL), which
is supplied in this distribution as LICENSE.

For installation instructions, please see the INSTALL file.
