<?php

$english = array(

	/**
	 * Friends widget
	 */
	'friends:widget:description' => "Displays some of your friends.",
	'friends:num_display' => "Number of friends to display",
	'friends:icon_size' => "Icon size",
	'friends:tiny' => "tiny",
	'friends:small' => "small",
);

add_translation("en", $english);
