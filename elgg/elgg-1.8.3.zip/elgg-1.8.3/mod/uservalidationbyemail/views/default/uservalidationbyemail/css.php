<?php
/**
 * CSS for user validation by email
 */
?>

.uservalidation-module > .elgg-head * {
	color: white;
}
.uservalidation-module > .elgg-body * {
	color: #333;
}