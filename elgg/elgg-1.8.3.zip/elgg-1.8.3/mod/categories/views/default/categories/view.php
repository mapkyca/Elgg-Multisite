<?php
/**
 * @deprecated 1.8
 */

elgg_deprecated_notice("Use output/categories instead of categories/view", 1.8);

echo elgg_view('output/categories', $vars);
