blockquote {
    margin:10px;
    border:1px solid #efefef;
    padding:4px;
}

strong {
    font-weight:bold;
}

ul {
   list-style: disc;
}

ol {
  list-style: decimal;
}