<?php
/**
 * Data format exception
 * An exception thrown when there is a problem in the format of some data.
 *
 * @package    Elgg.Core
 * @subpackage Exceptions.Stub
 */
class DataFormatException extends Exception {}
