<?php
namespace Elgg\Database;


class PluginsTest extends \PHPUnit_Framework_TestCase {

	public function testAfterPluginLoadActiveCheckIsFree() {
		$this->markTestIncomplete();
	}

	public function testPluginActivateAltersIsActive() {
		$this->markTestIncomplete();
	}

	public function testPluginDeactivateAltersIsActive() {
		$this->markTestIncomplete();
	}
}
