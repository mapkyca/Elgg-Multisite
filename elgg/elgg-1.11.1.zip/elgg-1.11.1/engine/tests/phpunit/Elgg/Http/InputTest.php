<?php
namespace Elgg\Http;

use PHPUnit_Framework_TestCase as TestCase;

class InputTest extends TestCase {
	
	public function testGetInputDefaultsToProvidedDefaultValue() {
		$this->markTestIncomplete();
	}
	
	public function testGetInputTriggersValidateInputHookIfAndOnlyIfFilteringIsEnabled() {
		$this->markTestIncomplete();
	}
	
	public function testGetInputCanBeOverriddenBySetInput() {
		$this->markTestIncomplete();
	}
	
	public function testGetInputChecksBothPostAndGetParams() {
		$this->markTestIncomplete();
	}
	
	public function testGetInputPushesInputContextDuringFiltering() {
		$this->markTestIncomplete();
	}
	
	public function testFilterTagsGlobal() {
		$this->markTestIncomplete();
	}
}