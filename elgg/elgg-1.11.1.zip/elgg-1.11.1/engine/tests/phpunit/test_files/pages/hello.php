<?php

echo $identifier . '/';
echo implode('/', $segments);
