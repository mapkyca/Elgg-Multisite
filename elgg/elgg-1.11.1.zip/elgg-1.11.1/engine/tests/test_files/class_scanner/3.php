<?php
namespace NS3_20130207;


interface I3_20130207 {

}

class C3_20130207 {

}

