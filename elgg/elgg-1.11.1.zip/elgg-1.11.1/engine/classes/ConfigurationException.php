<?php
/**
 * Configuration exception
 *
 * A generic parent class for Configuration exceptions
 *
 * @package    Elgg
 * @subpackage Exceptions.Stub
 */
class ConfigurationException extends \Exception {}
