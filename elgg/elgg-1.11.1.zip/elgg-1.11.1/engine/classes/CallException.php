<?php
/**
 * Call Exception Stub
 *
 * Generic parent class for Call exceptions
 *
 * @package    Elgg.Core
 * @subpackage Exceptions.Stub
 */
class CallException extends \Exception {}
