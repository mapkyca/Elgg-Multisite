<?php
/**
 * InvalidClassException
 * An invalid class Exception, throw when a class is invalid.
 *
 * @package    Elgg.Core
 * @subpackage Exception
 */
class InvalidClassException extends \ClassException {}
