<?php
namespace Elgg\Di;

/**
 * Missing value exception
 * 
 * @access private
 * 
 * @package Elgg.Core
 */
class MissingValueException extends \Exception {}

