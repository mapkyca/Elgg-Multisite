<?php
namespace Elgg\Di;

/**
 * Factory uncallable exception
 * 
 * @access private
 * 
 * @package Elgg.Core
 */
class FactoryUncallableException extends \Exception {}

