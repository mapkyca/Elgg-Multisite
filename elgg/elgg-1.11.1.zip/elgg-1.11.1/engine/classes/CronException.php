<?php
/**
 * Cron exception
 *
 * A generic parent class for cron exceptions
 *
 * @package    Elgg
 * @subpackage Exceptions.Stub
 */
class CronException extends \Exception {}
