Notes:

* A simple plugin to play mp3 files on the page
* http://wpaudioplayer.com/license
* http://wpaudioplayer.com/standalone

Instructions:

Drop into mod, enable in the admin panel and use.