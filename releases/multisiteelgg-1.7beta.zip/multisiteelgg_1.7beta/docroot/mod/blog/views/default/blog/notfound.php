<?php

	/**
	 * Elgg blog not found page
	 * 
	 * @package ElggBlog
	 */

?>

	<p>
		<?php

			echo elgg_echo("blog:notfound");
		
		?>
	</p>