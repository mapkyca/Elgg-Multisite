<?php
	echo $vars['url'] . "mod/groups/graphics/defaultmedium.gif";
?>