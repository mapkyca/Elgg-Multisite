<?php
	echo $vars['url'] . "mod/groups/graphics/defaultsmall.gif";
?>