<?php

	echo elgg_view('file/icon/text/directory',$vars);

?>