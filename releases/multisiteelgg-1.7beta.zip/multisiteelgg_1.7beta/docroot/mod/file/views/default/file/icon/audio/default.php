<?php

	echo elgg_view('file/icon/audio',$vars);

?>