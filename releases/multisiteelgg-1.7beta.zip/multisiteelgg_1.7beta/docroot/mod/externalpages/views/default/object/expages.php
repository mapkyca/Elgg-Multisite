<?php

	/**
	 * Elgg expages view
	 * 
	 * @package ElggExPages
	 * 
	 */

?>