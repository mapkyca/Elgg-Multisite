<?php

	/**
	 * Elgg externalpages CSS
	 * 
	 * @package externalpages
	 */

?>

/* IE6 */
* html #front_left_tbl { width:676px !important; }
* html #front_right_tbl { width:676px !important; }