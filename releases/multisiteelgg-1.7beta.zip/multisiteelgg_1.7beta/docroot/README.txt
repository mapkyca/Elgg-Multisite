Elgg
Copyright (c) 2008-2013 See COPYRIGHT.txt

See CONTRIBUTORS.txt for development credits.

The Elgg project was started in 2004 by:
Ben Werdmuller <ben@benwerd.com, http://benwerd.com> and 
Dave Tosh <davidgtosh@gmail.com>

The project site can be found at http://elgg.org/

Elgg is released under the GNU Public License (GPL) Version 2 and the 
Massachusetts Institute of Technology (MIT) License. See LICENSE.txt 
in the root of the package you downloaded.

For installation instructions, please see the INSTALL.txt file.
