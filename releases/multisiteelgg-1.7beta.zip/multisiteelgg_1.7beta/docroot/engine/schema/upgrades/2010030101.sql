ALTER TABLE `prefix_entities` CHANGE `last_action` `last_action` INT( 11 ) NOT NULL DEFAULT '0'
