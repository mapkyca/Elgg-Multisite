/**
	 * Elgg message board
	 * 
	 * @package ElggMessageBoard
	 * @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
	 * @author Dave Tosh <dave@elgg.com>
	 * @copyright Curverider Ltd 2008-2009
	 * @link http://elgg.com/
*/

This plugin provides Elgg profiles, both users and groups, with a basic message board for comments and media.

Install: Just drop it into the mod directory and that should be it.
