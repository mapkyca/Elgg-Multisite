<?php
/**
 * File CSS extender 
 * 
 * @package ElggFile
 */
?>
.file-photo {
	text-align: center;
	margin-bottom: 15px;
}
.file-gallery-item {
	text-align: center;
	width: 165px;
}
