<?php

echo elgg_view_module('info', 'Modules (.elgg-module)', elgg_view('theme_preview/modules/modules'));

echo elgg_view_module('info', 'Widgets (.elgg-module-widget)', elgg_view('theme_preview/modules/widgets'));

