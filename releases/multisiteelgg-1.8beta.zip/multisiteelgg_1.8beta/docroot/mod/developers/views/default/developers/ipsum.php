<?php
/**
 * Lorem ipsum text
 */
?>
Sed scelerisque sagittis lorem. Phasellus sodales.
Nulla urna justo, vehicula in, suscipit nec, molestie sed, tellus.