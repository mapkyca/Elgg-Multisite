<?php
/**
 * Categories input view
 *
 * @package ElggCategories
 *
 * @deprecated 1.8
 */

elgg_deprecated_notice("Use input/categories instead of categories", 1.8);

echo elgg_view('input/categories', $vars);
